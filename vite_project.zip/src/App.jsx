import React from "react";

const App = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900">
      <div className="text-center p-10 rounded-xl bg-white shadow-2xl">
        <h1 className="text-4xl font-bold text-blue-600 mb-4">
          Tailwind CSS is Working 🎉
        </h1>
        <p className="text-gray-600">
          If you see colors, spacing, and center alignment, Tailwind is installed correctly.
        </p>
        <button className="mt-6 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
          Test Button
        </button>
      </div>
    </div>
  );
};

export default App;
